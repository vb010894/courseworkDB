create definer = root@localhost trigger materials_AFTER_UPDATE
    after UPDATE
    on materials
    for each row
BEGIN
set @estimate = new.estimate;
update estimate set costAll = (select sum(cost) from materials where estimate = @estimate) where id = @estimate;
END;

