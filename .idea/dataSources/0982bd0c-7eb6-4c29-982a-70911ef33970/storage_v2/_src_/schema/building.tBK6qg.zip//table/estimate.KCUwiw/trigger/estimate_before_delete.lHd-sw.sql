create definer = root@localhost trigger estimate_BEFORE_DELETE
    before DELETE
    on estimate
    for each row
BEGIN
set @estimate = id;
delete from materials where estimate = @estimate;
END;

