create
    definer = root@localhost procedure deleteReport(IN idReport int)
BEGIN
	Select  @idsched := works.schedule, @idEstimate:= works.estimate from works where works.reports = id;
    delete from building.works where works.reports = id;
    delete from building.reports where id = id;
    delete from building.schedule where id = @idsched;
    delete from building.estimate where id = @idEstimate;
END;

