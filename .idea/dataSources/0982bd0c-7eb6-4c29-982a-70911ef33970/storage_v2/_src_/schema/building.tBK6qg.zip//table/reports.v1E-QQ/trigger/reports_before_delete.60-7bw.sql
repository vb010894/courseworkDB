create definer = root@localhost trigger reports_BEFORE_DELETE
    before DELETE
    on reports
    for each row
BEGIN
delete from building.`works` where `works`.`reports` = id;
END;

