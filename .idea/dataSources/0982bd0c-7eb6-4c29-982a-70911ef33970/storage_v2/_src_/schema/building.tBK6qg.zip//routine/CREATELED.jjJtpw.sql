create
    definer = root@localhost procedure CREATELED(IN id int)
BEGIN

  select @groupID := `group` from workeers where id = id limit 1; 
	
	update workeers set leader = 0 where `group` = @groupID;
    update workeers set leader = 1 where workeers.id = id;
END;

