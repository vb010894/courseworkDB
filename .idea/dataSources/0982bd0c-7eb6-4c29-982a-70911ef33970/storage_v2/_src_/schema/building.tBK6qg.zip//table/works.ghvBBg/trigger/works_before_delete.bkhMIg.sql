create definer = root@localhost trigger works_BEFORE_DELETE
    before DELETE
    on works
    for each row
BEGIN
  delete from building.`schedule` where id = schedule;
  delete from building.`estimate` where id = estimate;
END;

