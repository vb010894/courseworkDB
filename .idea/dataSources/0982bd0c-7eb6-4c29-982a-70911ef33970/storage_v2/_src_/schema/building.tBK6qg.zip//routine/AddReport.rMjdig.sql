create
    definer = root@localhost procedure AddReport(IN typeReport varchar(50),
                                                 IN descr varchar(200),
                                                 IN state varchar(1),
                                                 IN dateStartPlan date,
                                                 IN dateEndPlan date,
                                                 IN dateStartFact date,
                                                 IN dateEndFact date,
                                                 IN groupWork int)
BEGIN
	insert into building.schedule set schedule.startFact = dateStartFact, 
    schedule.endFact = dateEndFact, 
    schedule.planDate = dateStartPlan,
    schedule.endPlan = dateEndPlan;
        
    insert into building.estimate set estimate.description = descr;
    
    insert into building.`reports` set reports.description = descr;
        
    insert into building.`works` set `works`.`type` = typeReport, 
    `works`.`schedule` = (select MAX( id ) FROM building.`schedule`), 
    `works`.reports = (select MAX( id ) FROM building.reports),    
    `works`.estimate = (select MAX( id ) FROM building.estimate),
    `works`.status = state,
    `works`.`group` = groupWork;    
END;

